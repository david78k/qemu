#include "qemu-common.h"
#include "monitor/monitor.h"

void monitor_printf(Monitor *mon, const char *fmt, ...)
{
}

void monitor_vprintf(Monitor *mon, const char *fmt, va_list ap)
{
}
