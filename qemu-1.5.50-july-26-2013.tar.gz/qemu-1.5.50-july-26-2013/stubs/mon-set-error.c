#include "qemu-common.h"
#include "monitor/monitor.h"

Monitor *cur_mon;

void monitor_set_error(Monitor *mon, QError *qerror)
{
}
