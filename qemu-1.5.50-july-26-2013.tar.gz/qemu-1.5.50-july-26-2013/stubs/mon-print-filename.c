#include "qemu-common.h"
#include "monitor/monitor.h"

void monitor_print_filename(Monitor *mon, const char *filename)
{
}
