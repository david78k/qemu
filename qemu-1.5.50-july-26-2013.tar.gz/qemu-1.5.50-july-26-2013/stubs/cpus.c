#include "qemu-common.h"
#include "qom/cpu.h"

void cpu_resume(CPUState *cpu)
{
}

void qemu_init_vcpu(CPUState *cpu)
{
}
