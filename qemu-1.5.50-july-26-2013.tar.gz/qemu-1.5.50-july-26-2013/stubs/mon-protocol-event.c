#include "qemu-common.h"
#include "monitor/monitor.h"

void monitor_protocol_event(MonitorEvent event, QObject *data)
{
}
