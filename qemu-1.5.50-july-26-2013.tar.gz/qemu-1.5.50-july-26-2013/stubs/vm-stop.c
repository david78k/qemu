#include "qemu-common.h"
#include "sysemu/sysemu.h"

int vm_stop(RunState state)
{
    abort();
}
