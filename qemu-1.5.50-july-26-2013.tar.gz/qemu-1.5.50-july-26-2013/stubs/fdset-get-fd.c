#include "qemu-common.h"
#include "monitor/monitor.h"

int monitor_fdset_get_fd(int64_t fdset_id, int flags)
{
    return -1;
}
