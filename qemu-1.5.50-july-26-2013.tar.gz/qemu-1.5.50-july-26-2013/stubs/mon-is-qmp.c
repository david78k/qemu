#include "qemu-common.h"
#include "monitor/monitor.h"

int monitor_cur_is_qmp(void)
{
    return 0;
}
